﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfGestImmo.Data.DAL;

namespace WpfGestImmo
{
    public class Bien
    {
        private string? name;
        private double valeur;
        private double surface;
        private string adresse;
        private List<Bail> baux;
        private List<Intervention> interventions;
        private Pret? pret;

        public Bien(string name, double valeur, double surface, string adresse)
        {
            this.name = name;
            this.valeur = valeur;
            this.surface = surface;
            this.adresse = adresse;
            this.baux = new List<Bail>();
            this.interventions = new List<Intervention>();
            this.pret = null;
        }

        public int BienId { get; set; }
        public int Pret { get; set; }
        public string? Name { get => name; set => name = name; }
        public double Valeur { get => valeur; set => valeur = value; }
        public double Surface { get => surface; set => surface = value; }
        public string Adresse { get => adresse; set => adresse = value; }
        public List<Bail> Contrats { get => baux; set => baux = value; }
        public List<Intervention> Interventions { get => interventions; set => interventions = value; }
        
        /*public double calculerRentabiliteNetMensuel()
        {
            double loyer = 0;

            double mensualite = 0;
            if (this.pret != null)
            {
                mensualite = this.pret.calculerMensualite();
            }

            foreach (Bail b in this.baux)
            {
                if (b.DateFin == null)
                {
                    loyer = b.Loyer;
                }
            }

            double rentabilite = loyer - mensualite;
            return rentabilite;
        }*/

        public virtual double estimerValeur()
        {
            double prixMetreCarre = 1400;
            double prixSurface = prixMetreCarre * this.surface;

            return prixSurface;
        }
    }
}
