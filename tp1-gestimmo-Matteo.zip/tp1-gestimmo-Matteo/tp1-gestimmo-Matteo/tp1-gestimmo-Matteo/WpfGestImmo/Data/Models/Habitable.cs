﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfGestImmo.Data.DAL;

namespace WpfGestImmo
{
    public class Habitable : Bien
    {
        private int nbChambre;
        private int nbPiece;
        private bool parking;
        private bool cave;

        public Habitable(string name, double valeur, double surface, string adresse, int nbChambre, int nbPiece, bool parking, bool cave)
            : base(name, valeur, surface, adresse)
        {
            this.nbChambre = nbChambre;
            this.nbPiece = nbPiece;
            this.parking = parking;
            this.cave = cave;
        }

        public int NbChambre { get => nbChambre; set => nbChambre = value; }
        public int NbPiece { get => nbPiece; set => nbPiece = value; }
        public bool Parking { get => parking; set => parking = value; }
        public bool Cave { get => cave; set => cave = value; }

        public override double estimerValeur()
        {
            double valeur = base.estimerValeur();

            if (this.cave)
                valeur += 5000;
            if (this.parking)
                valeur += 8000;

            valeur += this.nbPiece * 2000;

            return valeur;
        }
    }
}
