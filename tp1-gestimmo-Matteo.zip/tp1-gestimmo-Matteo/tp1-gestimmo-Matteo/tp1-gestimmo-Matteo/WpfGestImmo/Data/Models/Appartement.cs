﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfGestImmo
{
    public class Appartement : Habitable
    {
        private int etage;
        private bool ascenseur;
        private bool chauffageCommun;

        public Appartement(string name, double valeur, double surface, string adresse, int nbChambre, int nbPiece, bool parking, bool cave, int etage, bool ascenseur, bool chauffageCommun)
            : base(name, valeur,surface, adresse, nbChambre, nbPiece, parking, cave)
        {
            this.etage = etage;
            this.ascenseur = ascenseur;
            this.chauffageCommun = chauffageCommun;
        }

        public int Etage { get => etage; set => etage = value; }
        public bool Ascenseur { get => ascenseur; set => ascenseur = value; }
        public bool ChauffageCommun { get => chauffageCommun; set => chauffageCommun = value; }

        public override double estimerValeur()
        {
            double valeur = base.estimerValeur();

            if (this.chauffageCommun)
                valeur += 6500;
            if (this.ascenseur)
                valeur += 5000;
            if (this.etage == 0)
                valeur -= 3000;

            return valeur;
        }
    }
}
