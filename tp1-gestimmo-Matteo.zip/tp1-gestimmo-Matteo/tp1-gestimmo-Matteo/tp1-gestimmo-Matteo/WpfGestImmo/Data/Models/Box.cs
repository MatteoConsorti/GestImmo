﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfGestImmo
{
    public class Box : Bien
    {
        public Box(string name ,double valeur, double surface, string adresse) : base(name, valeur, surface, adresse)
        {

        }
    }
}
