﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfGestImmo.Data.DAL;

namespace WpfGestImmo
{
    public class Pret
    {
        private double tauxInteret;
        private double montantPret;
        private double duree;
        private double mensualite;
        private double apport;
        private DateTime dateDebut;
        private Bien bien;
        private double duree1;

        public Pret(double tauxInteret, double montantPret, double duree, double mensualite, double apport, DateTime dateDebut)
        {
            this.tauxInteret = tauxInteret;
            this.montantPret = montantPret;
            this.duree = duree;
            this.mensualite = mensualite;
            this.apport = apport;
            this.dateDebut = dateDebut;
            this.bien = bien;
        }



        public int PretId { get; set; }
        public double TauxInteret { get => tauxInteret; set => tauxInteret = value; }
        public double MontantPret { get => montantPret; set => montantPret = value; }
        public double Duree { get => duree; set => duree = value; }
        public double Mensualite { get => mensualite; set => mensualite = value; }
        public double Apport { get => apport; set => apport = value; }
        public DateTime DateDebut { get => dateDebut; set => dateDebut = value; }
        public Bien Bien { get => bien; set => bien = value; }

       /* public double calculerMensualite()
        {
            double mensualite = (montantPret - this.apport) / this.duree;
            return mensualite;
        }*/

        public int obtenirNbMoisRestant()
        {
            DateTime dateJour = DateTime.Today;
            TimeSpan moisPaye = dateJour.Subtract(this.dateDebut);
            double nbMois = moisPaye.TotalDays / 30;

            double moisRestantAPaye = Math.Floor(this.duree - nbMois);
            return (int)moisRestantAPaye;
        }

        /*public double calculerCapitalRestantARembourser()
        {
            int mois = this.obtenirNbMoisRestant();
            double mensualite = this.calculerMensualite();
            double resteAPayer = (this.montantPret - ((this.duree - mois) * mensualite)) - this.apport;
            return resteAPayer;
        }*/
    }
}
