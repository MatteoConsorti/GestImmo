﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfGestImmo
{
    public class Maison : Habitable
    {
        public Maison(string name, double valeur, double surface, string adresse, int nbChambre, int nbPiece, bool parking, bool cave) 
            : base(name, valeur, surface, adresse, nbChambre, nbPiece, parking, cave)
        {
        }
    }
}
