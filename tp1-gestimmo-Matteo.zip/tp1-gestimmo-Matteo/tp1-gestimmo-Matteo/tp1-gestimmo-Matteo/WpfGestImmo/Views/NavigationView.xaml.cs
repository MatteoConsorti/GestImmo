﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfGestImmo.Views
{
    public partial class NavigationView : Page
    {
        public NavigationView()
        {
            InitializeComponent();
            this.MainFrame.Navigate(new HomeView());
        }
        private void btn_Click_0(object sender, RoutedEventArgs e)
        {
            this.MainFrame.Navigate(new HomeView());
        }

        private void btnBien_Click_1(object sender, RoutedEventArgs e)
        {
            this.MainFrame.Navigate(new BienView());
        }

        private void btnBien_Click_2(object sender, RoutedEventArgs e)
        {
            this.MainFrame.Navigate(new PretView());
        }
        private void btnBien_Click_3(object sender, RoutedEventArgs e)
        {
            this.MainFrame.Navigate(new InterventionView());
        }

        private void btnBien_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = (Button)sender;

            if (clickedButton.Name == "btnBien_Click_1")
            {
                this.MainFrame.Navigate(new BienView());
            }
            else if (clickedButton.Name == "btnBien_Click_2")
            {
                this.MainFrame.Navigate(new PretView());
            }
            else if (clickedButton.Name == "btnBien_Click_3")
            {
                this.MainFrame.Navigate(new InterventionView());
            }
        }

        private void MainFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }
    }
}
