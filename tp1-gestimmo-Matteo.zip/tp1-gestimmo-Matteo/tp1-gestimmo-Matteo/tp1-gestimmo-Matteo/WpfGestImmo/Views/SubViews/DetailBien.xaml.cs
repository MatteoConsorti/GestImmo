﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Forms;

namespace WpfGestImmo.Views.SubViews
{
    public partial class DetailBien : Page
    {
        private Bien selectedBien;

        public DetailBien(Bien bien)
        {
            InitializeComponent();
            selectedBien = bien;
            DisplayBienDetails();
        }

        private void DisplayBienDetails()
        {
            txtBienName.Text = selectedBien.Name;
            txtValeur.Text = selectedBien.Valeur.ToString();
            txtSurface.Text = selectedBien.Surface.ToString();
            txtAdresse.Text = selectedBien.Adresse;

        }
        private void btnModifyBien_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new ModifierBien(selectedBien));
        }


        private void btnDeleteBien_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Voulez-vous supprimer ce bien?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                GestImmoContext ctx = GestImmoContext.getInstance();
                ctx.Biens.Remove(selectedBien);
                ctx.SaveChanges();

                NavigationService?.Navigate(new ListBienView());
            }
        }
    }
}