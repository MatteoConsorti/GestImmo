﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo.Views.SubViews
{
    /// <summary>
    /// Logique d'interaction pour ListNomPrestataire.xaml
    /// </summary>
    public partial class ListNomPrestataire : IObserver
    {
        private ObservableCollection<Prestataire> prestataireList;

        public ListNomPrestataire()
        {
            InitializeComponent();
            prestataireList = new ObservableCollection<Prestataire>();
            lstPresta.ItemsSource = prestataireList;
            lstPresta.SelectionChanged += LstPresta_SelectionChanged;
            this.refreshList();

        }

        private void refreshList()
        {
            GestImmoContext ctx = GestImmoContext.getInstance();
            prestataireList.Clear();

            foreach (Prestataire prestataire in ctx.Prestataires)
            {
                prestataireList.Add(prestataire);
            }
        }

            

        public void update()
        {
            this.refreshList();
        }


    private void LstPresta_SelectionChanged( object sender, SelectionChangedEventArgs e)
        {
            if (lstPresta.SelectedItem != null)
            {
                Prestataire selectedPresta= (Prestataire) lstPresta.SelectedItem;
                NavigationService?.Navigate(new DetailPrestataire(selectedPresta));
                lstPresta.SelectedItem = null;
            }
        }
    }
}
