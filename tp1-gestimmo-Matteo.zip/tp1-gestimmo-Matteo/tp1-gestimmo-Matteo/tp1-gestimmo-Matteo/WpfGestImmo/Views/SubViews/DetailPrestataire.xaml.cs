﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Forms;

namespace WpfGestImmo.Views.SubViews
{
    /// <summary>
    /// Logique d'interaction pour DetailPrestataire.xaml
    /// </summary>
    public partial class DetailPrestataire : Page
    {
        private Prestataire selectedPrestataire;
        public DetailPrestataire(Prestataire prestataire)
        {
            InitializeComponent();
            selectedPrestataire = prestataire;
            DisplayPrestataireDetails();
        }

        private void  DisplayPrestataireDetails()
        {
            txtRaisonSociale.Text = selectedPrestataire.RaisonSociale;
            txtNomPrestataire.Text = selectedPrestataire.Nom;
            txtPrenomPrestataire.Text = selectedPrestataire.Prenom;
            txtTelephone.Text = selectedPrestataire.Telephone.ToString();
            txtAdresse.Text = selectedPrestataire.Adresse;
        }

        // Modifier
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate (new ModifierPrestataire(selectedPrestataire));
        }

        // Supprimer
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Voulez-vous supprimer ce prestataire .", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                GestImmoContext ctx = GestImmoContext.getInstance();
                ctx.Prestataires.Remove(selectedPrestataire);
                ctx.SaveChanges();

                NavigationService?.Navigate(new ListNomPrestataire());
            }
        }
    }
}
