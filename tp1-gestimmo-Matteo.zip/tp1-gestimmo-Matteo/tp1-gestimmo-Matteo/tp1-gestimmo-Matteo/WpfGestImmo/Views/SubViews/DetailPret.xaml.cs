﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Forms;

namespace WpfGestImmo.Views.SubViews
{
    /// <summary>
    /// Logique d'interaction pour DetailPret.xaml
    /// </summary>
    public partial class DetailPret : Page
    {
        private Pret selectedPret;
        public DetailPret(Pret pret)
        {
            InitializeComponent();
            selectedPret = pret;
            DisplayPretDetails();
        }

        private void DisplayPretDetails()
        {
            txtPretApport.Text = selectedPret.Apport.ToString();
            txtPretDuree.Text = selectedPret.Duree.ToString();

        }
        private void btnModifyPret_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new ModifierPret(selectedPret));
        }


        private void btnDeletePret_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Voulez-vous supprimer ce prêt?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                GestImmoContext ctx = GestImmoContext.getInstance();
                ctx.Prets.Remove(selectedPret);
                ctx.SaveChanges();

                NavigationService?.Navigate(new ListPretView());
            }
        }
    }
}