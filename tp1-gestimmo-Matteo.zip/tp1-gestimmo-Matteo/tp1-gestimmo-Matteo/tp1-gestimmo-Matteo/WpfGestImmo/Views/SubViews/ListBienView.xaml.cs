﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.SubViews;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo
{
    public partial class ListBienView : IObserver
    {
        private ObservableCollection<Bien> biensList;

        public ListBienView()
        {
            InitializeComponent();
            biensList = new ObservableCollection<Bien>();
            lstBiens.ItemsSource = biensList;
            lstBiens.SelectionChanged += LstBiens_SelectionChanged;
            this.refreshList();
        }

        private void refreshList()
        {
            GestImmoContext ctx = GestImmoContext.getInstance();

            biensList.Clear();

            foreach (Bien bien in ctx.Biens)
            {
                biensList.Add(bien);
            }
        }

        public void update()
        {
            this.refreshList();
        }

        private void LstBiens_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstBiens.SelectedItem != null)
            {
                Bien selectedBien = (Bien)lstBiens.SelectedItem;
                NavigationService?.Navigate(new DetailBien(selectedBien));
                lstBiens.SelectedItem = null;
            }
        }
    }
}