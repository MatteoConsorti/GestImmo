﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo.Views.Forms
{
    /// <summary>
    /// Logique d'interaction pour GererMaisonForm.xaml
    /// </summary>
    public partial class GererMaisonForm : IObservable
    {
        public GererMaisonForm()
        {
            InitializeComponent();
        }

        public List<Utils.IObserver> Observers { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = this.txtNameMaison.Text;
                int valeur = int.Parse(this.txtValeurMaison.Text);
                int surface = int.Parse(this.txtSurfaceMaison.Text);
                string adresse = this.txtAdresseMaison.Text;
                int nbChambre = int.Parse(this.txtNbChambreMaison.Text);
                int nbPiece = int.Parse(this.txtNbPieceMaison.Text);

                string parkingSelection = ((ComboBoxItem)cmbParkingMaison.SelectedItem).Content.ToString();
                bool parking = (parkingSelection == "Oui");

                string caveSelection = ((ComboBoxItem)cmbCaveMaison.SelectedItem).Content.ToString();
                bool cave = (caveSelection == "Oui");

                Maison maison = new Maison(name, valeur, surface, adresse, nbChambre, nbPiece, parking, cave);
                GestImmoContext ctx = GestImmoContext.getInstance();
                ctx.Biens.Add(maison);
                ctx.SaveChanges();

                this.notifyObservers();
                MessageBox.Show("Le bien a été ajouté avec succès.", "Succès");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Format d'entrée invalide. Veuillez saisir des valeurs numériques valides.", "Erreur");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Une erreur est survenue: {ex.Message}", "Erreur");
            }
        }
        void notifyObservers()
        {
            foreach (IObserver obs in Observers)
            {
                obs.update();
            }
        }
    }
}
