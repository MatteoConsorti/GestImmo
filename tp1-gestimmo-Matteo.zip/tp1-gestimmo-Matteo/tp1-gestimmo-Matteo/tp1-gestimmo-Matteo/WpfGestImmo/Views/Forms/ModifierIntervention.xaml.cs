﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.SubViews;

namespace WpfGestImmo.Views.Forms
{
    /// <summary>
    /// Logique d'interaction pour ModifierIntervention.xaml
    /// </summary>
    public partial class ModifierIntervention : Page
    {
        private Intervention selectedIntervention;
        public ModifierIntervention(Intervention intervention)
        {
            InitializeComponent();
            selectedIntervention = intervention;
            DisplayInterventionDetails();
        }

        private void DisplayInterventionDetails()
        {
            txtBien.Text = selectedIntervention.Bien.Name;
            txtPrestataire.Text = selectedIntervention.Prestataire.Nom;
            txtDate.Text = selectedIntervention.Date.ToString();
            txtMontant.Text = selectedIntervention.MontantTTC.ToString();
            txtInformations.Text = selectedIntervention.Information.ToString();
        }
        
        // Enregistrer
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                GestImmoContext ctx = GestImmoContext.getInstance();
                selectedIntervention.Date = Convert.ToDateTime(txtDate.Text);
                selectedIntervention.MontantTTC = Convert.ToDouble(txtMontant.Text);
                selectedIntervention.Information = txtInformations.Text;

                ctx.SaveChanges();
                NavigationService?.Navigate(new DetailIntervention(selectedIntervention));
            }

             catch (Exception ex) 
            {
                MessageBox.Show($"Une erreur est survenue : {ex.Message}", "Erreur");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new GererPrestatairesForm());
        }
    }
}
