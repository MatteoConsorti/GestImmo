﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo.Views.Forms
{
    /// <summary>
    /// Logique d'interaction pour GererBoxForm.xaml
    /// </summary>
    public partial class GererBoxForm : IObservable
    {
        public GererBoxForm()
        {
            InitializeComponent();
        }

        public List<Utils.IObserver> Observers { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string name = this.txtNameBox.Text;
                double valeur = double.Parse(this.txtValeurBox.Text);
                double surface = double.Parse(this.txtSurfaceBox.Text);
                string adresse = this.txtAdresseBox.Text;

                Box box = new Box(name, valeur, surface, adresse);
                GestImmoContext ctx = GestImmoContext.getInstance();

                ctx.Biens.Add(box);
                ctx.SaveChanges();

                this.notifyObservers();
                MessageBox.Show("Le bien a été ajouté avec succès.", "Succès");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Format d'entrée invalide. Veuillez saisir des valeurs numériques valides.", "Erreur");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Une erreur est survenue: {ex.Message}", "Erreur");
            }
        }

        void notifyObservers()
        {
            foreach (IObserver obs in Observers)
            {
                obs.update();
            }
        }
    }
}
