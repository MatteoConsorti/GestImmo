﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.SubViews;

namespace WpfGestImmo.Views.Forms
{
    /// <summary>
    /// Logique d'interaction pour ModifierPret.xaml
    /// </summary>
    public partial class ModifierPret : Page
    {
        private Pret selectedPret;
        public ModifierPret(Pret pret)
        {
            InitializeComponent();
            selectedPret = pret;
            DisplayPretDetails();
        }
        private void DisplayPretDetails()
        {
            txtModifiedPretApport.Text = selectedPret.Apport.ToString();
            txtModifiedPretDuree.Text = selectedPret.Duree.ToString();
        }

        private void btnSaveModificationPret_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                GestImmoContext ctx = GestImmoContext.getInstance();

                selectedPret.Apport = double.Parse(txtModifiedPretApport.Text);

                ctx.SaveChanges();

                NavigationService?.Navigate(new DetailPret(selectedPret));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Une erreur est survenue: {ex.Message}", "Erreur");
            }
        }
    }
}