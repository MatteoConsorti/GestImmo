﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Views.Forms;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo
{
    /// <summary>
    /// Logique d'interaction pour GererBienForm.xaml
    /// </summary>
    public partial class GererBienForm : Page, IObservable
    {
        public GererBienForm()
        {
            InitializeComponent();
            cmbTypeBien.SelectionChanged += cmbTypeBien_SelectionChanged;
        }

        public List<IObserver> Observers { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        private void cmbTypeBien_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (formFrame.NavigationService != null)
            {
                string typeBien = (cmbTypeBien.SelectedItem as ComboBoxItem)?.Content as string;

                try
                {
                    switch (typeBien)
                    {
                        case "Maison":
                            formFrame.NavigationService?.Navigate(new GererMaisonForm());
                            break;
                        case "Appartement":
                            formFrame.NavigationService?.Navigate(new GererAppartementForm());
                            break;
                        case "Box":
                            formFrame.NavigationService?.Navigate(new GererBoxForm());
                            break;
                        default:
                            MessageBox.Show("Sélection non prise en charge.", "Erreur de sélection");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur de navigation: {ex.Message}", "Erreur");
                }
            }
        }

        void notifyObservers()
        {
            foreach (IObserver obs in Observers)
            {
                obs.update();
            }
        }

        private void formFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }
    }
}