﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.SubViews;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo.Views.Forms
{
    /// <summary>
    /// Logique d'interaction pour GererInterPrestataire.xaml
    /// </summary>
    public partial class GererInterPrestataire : Page, IObservable
    {
        private IEnumerable biens;
        private IEnumerable prestataires;
        private List<IObserver> observers = new List<IObserver>();
        private object selectedPresta;

        public GererInterPrestataire()
        {
            InitializeComponent();
            biens = this.loadBiens();
            cmbPresta.ItemsSource = biens;
            cmbPresta.DisplayMemberPath = "Name";

            prestataires = this.loadPrestataires();
            cmbNomPresta.ItemsSource = prestataires;
            cmbNomPresta.DisplayMemberPath = "Name";
        }

        private List<Bien> loadBiens()
        {
            GestImmoContext ctx = GestImmoContext.getInstance();
            return ctx.Biens.ToList();
        }

        private List<Prestataire> loadPrestataires()
        {
            GestImmoContext context = GestImmoContext.getInstance();
            return context.Prestataires.ToList();
        }

        


        public List<IObserver> Observers
        {
            get => observers;
            set => observers = value;
        }




        // Ajouter une Interventions
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime date = DateTime.Parse(this.txtDate.Text);
                double montantTTC = double.Parse(this.txtMontant.Text);
                string informations = this.txtInfo.Text;
                Bien bien = (Bien)this.cmbPresta.SelectedItem;
                Prestataire prestataire = (Prestataire)this.cmbNomPresta.SelectedItem;

                Intervention inter = new Intervention(date, montantTTC, informations, bien, prestataire);
                GestImmoContext ctx = GestImmoContext.getInstance();

                ctx.Interventions.Add(inter);
                ctx.SaveChanges();

                this.notifyObservers();
                MessageBox.Show("L'intervention a été ajouté");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur survenue");
            }
        }

        void notifyObservers()
        {
            foreach (IObserver observer in observers)
            {
                observer.update();
            }
        }

        //Consulter Prestataires
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new GererPrestatairesForm());

        }
    }
}
