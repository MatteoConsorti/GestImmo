﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.SubViews;

namespace WpfGestImmo.Views.Forms
{
    /// <summary>
    /// Logique d'interaction pour ModifierPrestataire.xaml
    /// </summary>
    public partial class ModifierPrestataire : Page
    {
        private Prestataire selectedPrestataire;
        public ModifierPrestataire(Prestataire prestataire)
        {
            InitializeComponent();
            selectedPrestataire = prestataire;
            DisplayPrestataireDetail();
        }

        private void DisplayPrestataireDetail()
        {
            txtRaisonSociale.Text = selectedPrestataire.RaisonSociale;
            txtNom.Text = selectedPrestataire.Nom;
            txtPrenom.Text = selectedPrestataire.Prenom;
            txtTelehone.Text = selectedPrestataire.Telephone.ToString();
            txtAdresse.Text = selectedPrestataire.Adresse;
        }

        // Enregistrer
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                GestImmoContext ctx = GestImmoContext.getInstance();

                selectedPrestataire.RaisonSociale = txtRaisonSociale.Text;
                selectedPrestataire.Nom = txtNom.Text;
                selectedPrestataire.Prenom = txtPrenom.Text;
                selectedPrestataire.Telephone = txtTelehone.Text;
                selectedPrestataire.Adresse = txtAdresse.Text;

                ctx.SaveChanges();

                NavigationService?.Navigate(new DetailPrestataire(selectedPrestataire));
            }
            catch (Exception ex) 
            {
                MessageBox.Show($"Une erreur est survenue: {ex.Message}", "Erreur");

            }
        }

        // Gérer Interventions
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new GererInterPrestataire());
        }
    }
}
