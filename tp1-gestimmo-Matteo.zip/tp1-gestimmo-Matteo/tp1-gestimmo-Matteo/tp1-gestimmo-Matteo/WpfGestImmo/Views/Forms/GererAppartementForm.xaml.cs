﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo.Views.Forms
{
    /// <summary>
    /// Logique d'interaction pour GererAppartementForm.xaml
    /// </summary>
    public partial class GererAppartementForm : IObservable
    {
        public GererAppartementForm()
        {
            InitializeComponent();
        }

        public List<Utils.IObserver> Observers { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = this.txtNameAppartement.Text;
                int valeur = int.Parse(this.txtValeurAppartement.Text);
                int surface = int.Parse(this.txtSurfaceAppartement.Text);
                string adresse = this.txtAdresseAppartement.Text;
                int nbChambre = int.Parse(this.txtNbChambreAppartement.Text);
                int nbPiece = int.Parse(this.txtNbPieceAppartement.Text);

                string parkingSelection = ((ComboBoxItem)cmbParkingAppartement.SelectedItem).Content.ToString();
                bool parking = (parkingSelection == "Oui");

                string caveSelection = ((ComboBoxItem)cmbCaveAppartement.SelectedItem).Content.ToString();
                bool cave = (caveSelection == "Oui");

                int etage = int.Parse(this.txtEtageAppartement.Text);

                string ascenseurSelection = ((ComboBoxItem)cmbAscenseurAppartement.SelectedItem).Content.ToString();
                bool ascenseur = (ascenseurSelection == "Oui");

                string chauffageCommunSelection = ((ComboBoxItem)cmbChauffageCommunAppartement.SelectedItem).Content.ToString();
                bool chauffageCommun = (chauffageCommunSelection == "Oui"); 

                Appartement appartement = new Appartement(name, valeur, surface, adresse, nbChambre, nbPiece, parking, cave, etage, ascenseur, chauffageCommun);
                GestImmoContext ctx = GestImmoContext.getInstance();
                ctx.Biens.Add(appartement);
                ctx.SaveChanges();

                this.notifyObservers();
                MessageBox.Show("Le bien a été ajouté avec succès.", "Succès");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Format d'entrée invalide. Veuillez saisir des valeurs numériques valides.", "Erreur");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Une erreur est survenue: {ex.Message}", "Erreur");
            }
        }
        void notifyObservers()
        {
            foreach (IObserver obs in Observers)
            {
                obs.update();
            }
        }
    }
}
