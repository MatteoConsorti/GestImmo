﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Data.DAL;
using WpfGestImmo.Views.Forms;
using WpfGestImmo.Views.Utils;

namespace WpfGestImmo.Views.SubViews
{
    /// <summary>
    /// Logique d'interaction pour GererPrestatairesForm.xaml
    /// </summary>
    public partial class GererPrestatairesForm : IObservable
    {
        public GererPrestatairesForm()
        {
            InitializeComponent();
        }

        private List<Utils.IObserver> _observers = new List<Utils.IObserver>();

        public List<Utils.IObserver> Observers
        {
            get { return _observers; }
            set { _observers = value; }
        }



        void notifyObservers()
        {
            foreach (IObserver obs in Observers)
            {
                obs.update();
            }
        }

      
        

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new GererInterPrestataire());
        }

        // Ajouter un prestataire
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                string raisonSociale = this.txtRaisonPrestataire.Text;
                string nom = this.txtNomPrestataire.Text;
                string prenom = this.txtPrenomPrestataire.Text;
                string telephone = this.txtTelephonePrestataire.Text;
                string adresse = this.txtAdressePrestataire.Text;

                Prestataire prestataire = new Prestataire(raisonSociale, nom, prenom, telephone, adresse);

                GestImmoContext.getInstance().Prestataires.Add(prestataire);
                GestImmoContext.getInstance().SaveChanges();

                this.notifyObservers();
                MessageBox.Show("Le prestataire a été ajouté avec succès.", "Succès");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Format d'entrée invalide. Veuillez saisir des valeurs valides.", "Erreur");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Une erreur est survenue: {ex.Message}", "Erreur");
            }
        }
    }
}
