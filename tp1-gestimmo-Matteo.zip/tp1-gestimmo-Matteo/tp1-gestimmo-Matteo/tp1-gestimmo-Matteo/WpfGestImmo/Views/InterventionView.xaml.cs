﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfGestImmo.Views.Forms;
using WpfGestImmo.Views.SubViews;

namespace WpfGestImmo.Views
{
    /// <summary>
    /// Logique d'interaction pour InterventionView.xaml
    /// </summary>
    public partial class InterventionView : Page
    {
        private ListNomPrestataire listNomPresta;
        private GererInterPrestataire gererInterPrestataire;
        private ListPrestaView listPresta;
        public InterventionView()
        {
            InitializeComponent();

            listNomPresta = new ListNomPrestataire();
            gererInterPrestataire = new GererInterPrestataire();
            listPresta = new ListPrestaView();

            InterPrestaFrameGauche.Navigate(listNomPresta);
            InterPrestaFrameDroite.Navigate(gererInterPrestataire);
            PrestaFrameGauche.Navigate(listPresta);
        }

        private void ShowListPrestaView(object sender, RoutedEventArgs e)
        {
            InterPrestaFrameGauche.Navigate(listNomPresta);
        }

        private void ShowGererPrestatairesForm(object sender, RoutedEventArgs e)
        {
            InterPrestaFrameDroite.Navigate(gererInterPrestataire);
        }

        private void ShowListInterPrestaView(object sender, RoutedEventArgs e)
        {
            PrestaFrameGauche.Navigate (listNomPresta);
        }
    }
}
